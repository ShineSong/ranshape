function residual=ResidualOfCircle(param,data)
    [tht,rho]=cart2pol(data(:,1)-param(1),data(:,2)-param(2));
    residual=rho-param(3);
end