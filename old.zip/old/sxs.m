sContour=sortContour(oct2Contour);
%�ж�˳ʱ����ʱ��
angleTable=CalcAngleTable(sContour);
if sum(angleTable) > (length(angleTable)-2+0.1)*pi
    a='��ʱ��'
else
    a='˳ʱ��'
    sContour=flipud(sContour);
end

dnContour=contourDenoise(sContour);
plot([dnContour(:,1);dnContour(1,1)],[dnContour(:,2);dnContour(1,2)])
hold on
axis equal
theta=[0:360]*pi/180;

[x,y,r,rms]=fitCircle(dnContour);
[param,resnorm,residual,exitflag,output]=lsqnonlin(@ResidualOfRegularPolygon,[x y 0 r],[],[],[],dnContour,0);
rms=sqrt(sum(residual.^2)/length(residual));
likehood=rms;
rectangle('Position',[param(1)-param(4),param(2)-param(4),param(4)*2,param(4)*2],'Curvature',[1 1],'LineStyle','--')

[x,y,r,a,rms]=fitTriangle(dnContour);
[param,resnorm,residual,exitflag,output]=lsqnonlin(@ResidualOfRegularPolygon,[x y a r],[],[],[],dnContour,3);
rms=sqrt(sum(residual.^2)/length(residual));
likehood=[likehood rms];
rho=PolarRegularModel(3,param(4),param(3),theta);
[XX,YY]=pol2cart(theta,rho);
plot(XX+param(1),YY+param(2),'r--');

[x,y,r,a,rms]=fitOctagon(dnContour)
[param,resnorm,residual,exitflag,output]=lsqnonlin(@ResidualOfRegularPolygon,[x y a r],[],[],[],dnContour,8);
rms=sqrt(sum(residual.^2)/length(residual));
likehood=[likehood rms];
rho=PolarRegularModel(8,param(4),param(3),theta);
[XX,YY]=pol2cart(theta,rho);
plot(XX+param(1),YY+param(2),'g--');

[x,y,r,a,rms]=fitHexagon(dnContour);
[param,resnorm,residual,exitflag,output]=lsqnonlin(@ResidualOfRegularPolygon,[x y a r],[],[],[],dnContour,6);
rms=sqrt(sum(residual.^2)/length(residual));
likehood=[likehood rms];
rho=PolarRegularModel(6,param(4),param(3),theta);
[XX,YY]=pol2cart(theta,rho);
plot(XX+param(1),YY+param(2),'b--');

[x,y,w,h,a,rms]=fitRectangle(dnContour);
[param,resnorm,residual,exitflag,output]=lsqnonlin(@ResidualOfRectangle,[x y w h a],[],[],[],dnContour);
rms=sqrt(sum(residual.^2)/length(residual));
likehood=[likehood rms];
rho=PolarRectangleModel(param(3),param(4),param(5),theta);
[XX,YY]=pol2cart(theta,rho);
plot(XX+x,YY+y,'c--');


likehood
result=find(likehood==min(likehood))